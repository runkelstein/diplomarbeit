Imports System
Imports Microsoft.Windows.Design.Features
Imports Microsoft.Windows.Design.Interaction

' The DiagnosticsMenuProvider class adds a context menu item
' that displays a dialog box listing the currently running and 
' pending feature connectors. 
<FeatureConnector(GetType(DiagnosticsFeatureConnector))>  _
Public Class DiagnosticsMenuProvider
    Inherits PrimarySelectionContextMenuProvider
    
    Public Sub New() 
        Dim action As New MenuAction("Feature Diagnostics...")
        
        AddHandler action.Execute, AddressOf action_Execute 
        
        Items.Add(action)    
    End Sub
    
    Sub action_Execute(ByVal sender As Object, ByVal e As MenuActionEventArgs) 
        Dim service As IDiagnosticsService = e.Context.Services.GetRequiredService(Of IDiagnosticsService)()
        
        service.ShowWindow()
    
    End Sub

End Class

' The IDiagnosticsService specifies a simple interface for showing
' a FeatureManagerDiagnostics window.
Interface IDiagnosticsService
    Sub ShowWindow() 
End Interface

' The DiagnosticsFeatureConnector publishes the IDiagnosticsService. 
Class DiagnosticsFeatureConnector
    Inherits FeatureConnector(Of DiagnosticsMenuProvider)
    Implements IDiagnosticsService
     
    Dim fmdWindow As FeatureManagerDiagnostics

    Public Sub New(ByVal manager As FeatureManager) 
        MyBase.New(manager)

        Context.Services.Publish(Of IDiagnosticsService)(Me)

    End Sub

    ' The showWindow method creates a FeatureManagerDiagnostics
    ' window and shows it.
    Public Sub ShowWindow() Implements IDiagnosticsService.ShowWindow

        If fmdWindow IsNot Nothing Then

            ' Show the FeatureManagerDiagnostics window.
            fmdWindow.Show()

            ' Activate the 
            fmdWindow.Activate()

        Else

            fmdWindow = New FeatureManagerDiagnostics()
            fmdWindow.Initialize(Manager)
            AddHandler fmdWindow.Closed, AddressOf fmdWindow_Closed
            fmdWindow.Show()

        End If

    End Sub

    Sub fmdWindow_Closed(ByVal sender As Object, ByVal e As EventArgs)

        fmdWindow = Nothing

    End Sub

End Class
