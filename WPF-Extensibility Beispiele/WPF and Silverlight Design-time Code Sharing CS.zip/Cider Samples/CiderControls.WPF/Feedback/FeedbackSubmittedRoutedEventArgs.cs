﻿using System.Windows;

namespace CiderControls {

    public class FeedbackSubmittedRoutedEventArgs : RoutedEventArgs {

        #region Properites

        public int Value { get; set; }
        public string Comment { get; set;}

        #endregion

        #region Constructors

        public FeedbackSubmittedRoutedEventArgs()
            : base() { }

        public FeedbackSubmittedRoutedEventArgs(System.Windows.RoutedEvent routedEvent)
            : base(routedEvent) { }

        public FeedbackSubmittedRoutedEventArgs(System.Windows.RoutedEvent routedEvent, object source)
            : base(routedEvent, source) { }

        public FeedbackSubmittedRoutedEventArgs(System.Windows.RoutedEvent routedEvent, object source, int value, string comment)
            : base(routedEvent, source) {

                Value = value;
                Comment = comment;

        }

        #endregion
    }
}
