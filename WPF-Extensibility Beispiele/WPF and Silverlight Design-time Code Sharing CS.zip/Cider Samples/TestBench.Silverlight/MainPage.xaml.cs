﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TestBench.Silverlight
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(MainPage_Loaded);
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e) {
            this.feedback1.FeedbackSubmitted += new EventHandler<CiderControls.FeedbackSubmittedEventArgs>(feedback_FeedbackSubmitted);
            this.feedback2.FeedbackSubmitted +=new EventHandler<CiderControls.FeedbackSubmittedEventArgs>(feedback_FeedbackSubmitted);
            this.feedback1.Cancel += new EventHandler<EventArgs>(feedback_Cancel);
            this.feedback2.Cancel +=new EventHandler<EventArgs>(feedback_Cancel);
        }

        void feedback_Cancel(object sender, EventArgs e) {
            MessageBox.Show("Send feedback later.");
        }

        void feedback_FeedbackSubmitted(object sender, CiderControls.FeedbackSubmittedEventArgs e) {
            MessageBox.Show(string.Format("Thank you for voting: {0} and submitting this comment: {1}", e.Value, e.Comment));
        }
    }
}
