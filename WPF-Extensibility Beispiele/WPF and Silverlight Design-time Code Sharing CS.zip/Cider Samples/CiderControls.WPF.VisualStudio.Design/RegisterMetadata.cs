﻿using CiderControls.Common.VisualStudio.Design.Registration;
using CiderControls.WPF.VisualStudio.Design;
using Microsoft.Windows.Design.Metadata;

//TODO  1 - WPF - Visual Studio uses this attribute to locate and instantiate RegisterMetadata
//
// The below attribute should be in AssemblyInfo.cs - declaring here to make it obvious.
//
[assembly: ProvideMetadata(typeof(RegisterMetadata))]

namespace CiderControls.WPF.VisualStudio.Design {

    //TODO  2 - WPF - Register Metadata provides an AttributeTable (metadata).

    /// <summary>
    /// Metadata is used by VS to associate your control design code with the control
    /// Notice the WPFTypeResolver.  This is used by the CiderControlsAttributeTableBuilder to get
    /// platform specific types in platform neutral code.
    /// </summary>
    internal class RegisterMetadata : IProvideAttributeTable {

        AttributeTable IProvideAttributeTable.AttributeTable {
            get {
                //TODO  3 - WPF - WPFTypeResolver provides WPF Types to CiderControlsAttributeTableBuilder which is platform neutral
                CiderControlsAttributeTableBuilder builder = new CiderControlsAttributeTableBuilder(new WPFTypeResolver());
                return builder.CreateTable();
            }
        }
    }
}
