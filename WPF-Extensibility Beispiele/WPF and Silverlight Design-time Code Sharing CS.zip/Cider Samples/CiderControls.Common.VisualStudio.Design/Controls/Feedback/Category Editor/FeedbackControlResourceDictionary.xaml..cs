﻿using System;
using System.Windows;
using CiderControls.Common.VisualStudio.Design.Infrastructure;

namespace CiderControls.Common.VisualStudio.Design.Controls {

    //TODO 12 - FeedbackControlResourceDictionary

    /// <summary>
    /// The FeedbackCategoryEditor property supplies a strong typed access to the FeedBackCategoryEditor DataTemplate
    /// in the FeedbackControlResourceDictionary.xaml file.
    ///    
    /// This class implements the Singleton pattern so that the resource dictionary is only created once
    /// and is accessed through the Instance property.
    /// </summary>
    internal partial class FeedbackControlResourceDictionary : ResourceDictionary {

        [ThreadStatic]
        private static FeedbackControlResourceDictionary _instance;

        private FeedbackControlResourceDictionary() {
            InitializeComponent();
        }

        /// <summary>
        /// return a cached copy of the resource dictionary
        /// </summary>
        internal static FeedbackControlResourceDictionary Instance {
            get {
                if (_instance == null) {
                    _instance = new FeedbackControlResourceDictionary();
                }
                return _instance;
            }
        }

        /// <summary>
        /// DataTemplate for the FeedbackCategoryEditor
        /// </summary>
        public DataTemplate FeedbackCategoryEditor {
            get {
                return this[Constants.STR_FEEDBACKCATEGORYEDITORTEMPLATE] as DataTemplate;
            }
        }
    }
}
