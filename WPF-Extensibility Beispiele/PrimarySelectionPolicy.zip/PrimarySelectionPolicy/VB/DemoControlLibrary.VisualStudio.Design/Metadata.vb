Imports System
Imports DemoControlLibrary

Imports Microsoft.Windows.Design.Metadata
Imports Microsoft.Windows.Design.Features

' The ProvideMetadata assembly-level attribute indicates to designers
' that this assembly contains a class that provides an attribute table. 
<Assembly: ProvideMetadata(GetType(DemoControlLibrary.VisualStudio.Design.Metadata))> 

' Container for any general design-time metadata to initialize.
' Designers look for a type in the design-time assembly that 
' implements IProvideAttributeTable. If found, designers instantiate
' this class and access its AttributeTable property automatically.
Friend Class Metadata
    Implements IProvideAttributeTable

    ' Accessed by the designer to register any design-time metadata.
    Public ReadOnly Property AttributeTable() As AttributeTable _
        Implements IProvideAttributeTable.AttributeTable
        Get
            Dim builder As New AttributeTableBuilder()
            InitializeAttributes(builder)
            Return builder.CreateTable()
        End Get
    End Property

    Private Sub InitializeAttributes(ByVal builder As AttributeTableBuilder) 
        builder.AddCallback(GetType(DemoDockPanel), AddressOf AddDockPanelAttributes)
    
    End Sub
    
    Private Sub AddDockPanelAttributes(ByVal builder As AttributeCallbackBuilder) 
        builder.AddCustomAttributes( _
            New FeatureAttribute(GetType(DockPanelAdornerProvider)), _
            New FeatureAttribute(GetType(DockPanelContextMenuProvider)))
    End Sub
End Class
