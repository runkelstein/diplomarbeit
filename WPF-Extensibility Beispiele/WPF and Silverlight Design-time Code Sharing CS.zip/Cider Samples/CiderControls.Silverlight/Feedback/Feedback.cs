﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace CiderControls {
    
    [TemplatePart(Name = "PART_SubmitButton", Type = typeof(Button))]
    [TemplatePart(Name = "PART_CancelButton", Type = typeof(Button))]
    public class Feedback : Control {

        #region Declarations

        private Button _btnCancel;
        private Button _btnSubmit;
        private const int _minValue = 1;
        private const int _maxValue = 5;
        private const int _unSetValue = 0;

        #endregion

        #region Dependency Properties

        public static readonly DependencyProperty CornerRadiusProperty = DependencyProperty.Register("CornerRadius", typeof(CornerRadius), typeof(Feedback),
            new PropertyMetadata(new CornerRadius()));

        public static readonly DependencyProperty HeaderProperty = DependencyProperty.Register("Header", typeof(object), typeof(Feedback),
            new PropertyMetadata(null));

        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register("Value", typeof(int), typeof(Feedback),
            new PropertyMetadata(_unSetValue));

        public static readonly DependencyProperty CommentProperty = DependencyProperty.Register("Comment", typeof(string), typeof(Feedback),
            new PropertyMetadata(null));

        public static readonly DependencyProperty CommentHeadingProperty = DependencyProperty.Register("CommentHeading", typeof(string), typeof(Feedback),
            new PropertyMetadata("Your comment is appreciated"));

        public CornerRadius CornerRadius {
            get { return (CornerRadius)GetValue(CornerRadiusProperty); }
            set { SetValue(CornerRadiusProperty, value); }
        }

        public object Header {
            get { return GetValue(HeaderProperty); }
            set { SetValue(HeaderProperty, value); }
        }

        public int Value {
            get { return (int)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        public string Comment {
            get { return (string)GetValue(CommentProperty); }
            set { SetValue(CommentProperty, value); }
        }

        public string CommentHeading {
            get { return (string)GetValue(CommentHeadingProperty); }
            set { SetValue(CommentHeadingProperty, value); }
        }

        #endregion

        #region Events

        public event EventHandler<FeedbackSubmittedEventArgs> FeedbackSubmitted;
        
        protected virtual void RaiseFeedbackSubmitted(int value, string comment) {
            if (FeedbackSubmitted != null)
                FeedbackSubmitted(this, new FeedbackSubmittedEventArgs(value, comment));
        }

        public event EventHandler<EventArgs> Cancel;
        
        protected virtual void RaiseCancel() {
            if (Cancel != null)
                Cancel(this, EventArgs.Empty);
        }

        #endregion

        #region Constructor

        public Feedback() {
            this.DefaultStyleKey = typeof(Feedback);
        }

        #endregion

        #region Methods

        public override void OnApplyTemplate() {
            base.OnApplyTemplate();

            _btnCancel = this.GetTemplateChild("PART_CancelButton") as Button;

            if (_btnCancel == null)
                throw new Exception("Template control PART_CancelButton was not found.");

            _btnSubmit = this.GetTemplateChild("PART_SubmitButton") as Button;

            if (_btnSubmit == null)
                throw new Exception("Template control PART_SubmitButton was not found.");

            _btnCancel.Click += new RoutedEventHandler(_btnCancel_Click);
            _btnSubmit.Click += new RoutedEventHandler(_btnSubmit_Click);

        }

        void _btnSubmit_Click(object sender, RoutedEventArgs e) {
            RaiseFeedbackSubmitted(this.Value, this.Comment);
        }

        void _btnCancel_Click(object sender, RoutedEventArgs e) {
            RaiseCancel();
        }

        #endregion
    }
}
