﻿using Microsoft.Windows.Design.PropertyEditing;

namespace CiderControls.Common.VisualStudio.Design.Controls {

    //TODO 15 - FeedbackControlCategoryEditor
    // http://msdn.microsoft.com/en-us/library/microsoft.windows.design.propertyediting.propertyvalueeditor(VS.100).aspx

    /// <summary>
    /// Rating control property value editor
    /// </summary>
    internal class RatingSelectorInlineEditor : PropertyValueEditor {

        public RatingSelectorInlineEditor() {
            this.InlineEditorTemplate = RatingEditorResourceDictionary.Instance.RatingSelector;
        }
    }
}
