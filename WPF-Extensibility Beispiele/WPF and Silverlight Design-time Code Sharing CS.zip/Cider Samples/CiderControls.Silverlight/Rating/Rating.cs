﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Shapes;

namespace CiderControls {

    [TemplatePart(Name = "PART_LayoutGrid", Type = typeof(Grid))]
    public class Rating : Control {

        #region Declarations

        private Grid _layoutGrid;
        private Style _unsetEllipseStyle;
        private Style _setEllipseStyle;
        private const int _minValue = 1;
        private const int _maxValue = 5;
        private const int _unSetValue = 0;

        #endregion

        #region Events

        public event EventHandler<ValueSelectedEventArgs> ValueSelected;

        protected virtual void OnValueSelected() {
            if (ValueSelected != null)
                ValueSelected(this, new ValueSelectedEventArgs(this.Value));
        }

        #endregion

        #region Dependency Properties

        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register("Value", typeof(int), typeof(Rating),
            new PropertyMetadata(_unSetValue, new PropertyChangedCallback(OnValueChanged)));

        public int Value {
            get { return (int)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        private static void OnValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            Rating r = (Rating)d;
            r.RenderValue((int)e.NewValue);
        }

        #endregion

        #region Constructors

        public Rating() {
            this.DefaultStyleKey = typeof(Rating);
            this.Loaded += new RoutedEventHandler(Rating_Loaded);
        }

        #endregion

        #region Methods

        public override void OnApplyTemplate() {
            base.OnApplyTemplate();

            _layoutGrid = this.GetTemplateChild("PART_LayoutGrid") as Grid;
            if (_layoutGrid == null)
                throw new Exception("Template control PART_LayoutGrid was not found.");

            _unsetEllipseStyle = _layoutGrid.Resources["unsetEllipseStyle"] as Style;
            if (_unsetEllipseStyle == null)
                throw new Exception("Template style unsetEllipseStyle was not found.");

            _setEllipseStyle = _layoutGrid.Resources["setEllipseStyle"] as Style;
            if (_setEllipseStyle == null)
                throw new Exception("Template style setEllipseStyle was not found.");
        }

        void Rating_Loaded(object sender, RoutedEventArgs e) {

            _layoutGrid.MouseLeave += new MouseEventHandler(_layoutGrid_MouseLeave);

            Ellipse ellp;
            ToolTip tt = new ToolTip();
            tt.Content = "Click to set value.  If already set, clicking will set value to zero.";

            for (int intX = _minValue; intX <= _maxValue; intX++) {
                _layoutGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(18) });
                ellp = new Ellipse { Tag = intX, Style = _unsetEllipseStyle };
                ellp.SetValue(Grid.ColumnProperty, intX - 1);
                ellp.MouseEnter += new MouseEventHandler(ellp_MouseEnter);
                ellp.MouseLeftButtonUp += new MouseButtonEventHandler(ellp_MouseLeftButtonUp);
                ToolTipService.SetToolTip(ellp, tt);
                _layoutGrid.Children.Add(ellp);
            }

            RenderValue(this.Value);

        }

        void ellp_MouseLeftButtonUp(object sender, MouseButtonEventArgs e) {
            Ellipse ellp = (Ellipse)sender;
            int value = (int)ellp.Tag;
            if (value != this.Value) {
                this.Value = (int)ellp.Tag;
                OnValueSelected();
                e.Handled = true;
            } else {
                this.Value = _unSetValue;
                OnValueSelected();
                e.Handled = true;
            }
        }

        void ellp_MouseEnter(object sender, MouseEventArgs e) {
            Ellipse ellp = (Ellipse)sender;
            int value = (int)ellp.Tag;
            RenderValue(value);
        }

        void _layoutGrid_MouseLeave(object sender, MouseEventArgs e) {
            RenderValue(this.Value);
        }

        void RenderValue(int value) {
            if (_layoutGrid == null || _layoutGrid.Children == null)
                return;

            foreach (Ellipse elp in _layoutGrid.Children) {
                if ((int)elp.Tag <= value) {
                    elp.Style = _setEllipseStyle;
                }
                else {
                    elp.Style = _unsetEllipseStyle;
                }
            }
        }

        #endregion
    }
}
