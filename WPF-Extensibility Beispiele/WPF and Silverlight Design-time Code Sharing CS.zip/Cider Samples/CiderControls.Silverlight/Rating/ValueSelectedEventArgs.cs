﻿using System;

namespace CiderControls {
    
    public class ValueSelectedEventArgs : EventArgs {

        #region Properites

        public int Value { get; set; }

        #endregion

        #region Constructor

        public ValueSelectedEventArgs(int value)
            : base() {

            Value = value;

        }

        #endregion
    }
}
