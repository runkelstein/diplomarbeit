using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;

using Microsoft.Windows.Design.Interaction;

namespace DemoControlLibrary.VisualStudio.Design
{
    // A DockPanelMarginTask is attached to to the adorner
    // offered by the DockPanelAdornerProvider class. When 
    // you drag the adorner, the target control's Margin
    // property changes. 
    class DockPanelMarginTask : Task 
    {
        InputBinding dragBinding, endDragBinding;
        Thickness initialMargin;

        // The DockPanelMarginTask constructor establishes mappings 
        // between user inputs and commands. 
        public DockPanelMarginTask() 
        {
            ToolCommand beginDrag = new ToolCommand("BeginDrag");
            ToolCommand drag = new ToolCommand("Drag");
            ToolCommand endDrag = new ToolCommand("EndDrag");
            ToolCommand resetMargins = new ToolCommand("ResetMargins");

            this.InputBindings.Add(
                new InputBinding(
                    beginDrag, 
                    new ToolGesture(ToolAction.DragIntent, MouseButton.Left)));

            this.InputBindings.Add(
                new InputBinding(
                    resetMargins, 
                    new ToolGesture(ToolAction.DoubleClick, MouseButton.Left)));

            this.dragBinding = new InputBinding(
                drag, 
                new ToolGesture(ToolAction.Move));

            this.endDragBinding = new InputBinding(
                endDrag, 
                new ToolGesture(ToolAction.DragComplete));

            this.ToolCommandBindings.Add(
                new ToolCommandBinding(beginDrag, OnBeginDrag));
            this.ToolCommandBindings.Add(
                new ToolCommandBinding(drag, OnDrag));
            this.ToolCommandBindings.Add(
                new ToolCommandBinding(endDrag, OnEndDrag));
            this.ToolCommandBindings.Add(
                new ToolCommandBinding(resetMargins, OnResetMargins));
        }

        private void OnBeginDrag(object sender, ExecutedToolEventArgs args) 
        {
            GestureData data = GestureData.FromEventArgs(args);
           
            this.BeginFocus(data);
            this.InputBindings.Add(dragBinding);
            this.InputBindings.Add(endDragBinding);

            this.initialMargin = (Thickness)data.ImpliedSource.Properties[
                "Margin"].ComputedValue;
        }

        private void OnDrag(object sender, ExecutedToolEventArgs args) 
        {
            MouseGestureData data = MouseGestureData.FromEventArgs(args);
            double offX = data.PositionDelta.X;
            double offY = data.PositionDelta.Y;

            Thickness newMargin = initialMargin;

            newMargin.Bottom += offY;
            newMargin.Top += offY;
            newMargin.Left += offX;
            newMargin.Right += offX;

            data.ImpliedSource.Properties["Margin"].SetValue(newMargin);
        }

        private void OnEndDrag(object sender, ExecutedToolEventArgs args) 
        {
            Description = "Adjust margin";
            this.Complete();
        }

        protected override void OnCompleted(EventArgs e)
        {
            this.Cleanup();
            base.OnCompleted(e);
        }

        protected override void OnReverted(EventArgs e)
        {
            this.Cleanup();
            base.OnReverted(e);
        }

        private void Cleanup()
        {
            this.InputBindings.Remove(dragBinding);
            this.InputBindings.Remove(endDragBinding);
        }

        private void OnResetMargins(object sender, ExecutedToolEventArgs args) 
        {
            GestureData data = GestureData.FromEventArgs(args);
            data.ImpliedSource.Properties["Margin"].ClearValue();
        }

    }
}
