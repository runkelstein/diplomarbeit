﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace CiderControls {
    
    [DefaultEvent("FeedbackSubmitted")]
    [TemplatePart(Name = "PART_SubmitButton", Type = typeof(Button))]
    [TemplatePart(Name = "PART_CancelButton", Type = typeof(Button))]
    public class Feedback : Control {

        #region Declarations

        private Button _btnCancel;
        private Button _btnSubmit;

        #endregion

        #region Dependency Properties

        public static readonly DependencyProperty CornerRadiusProperty = DependencyProperty.Register("CornerRadius", typeof(CornerRadius), typeof(Feedback),
            new FrameworkPropertyMetadata(new CornerRadius(), FrameworkPropertyMetadataOptions.AffectsRender));

        public static readonly DependencyProperty HeaderProperty = DependencyProperty.Register("Header", typeof(object), typeof(Feedback),
            new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.AffectsArrange));

        public static readonly DependencyProperty ValueProperty = Rating.ValueProperty.AddOwner(typeof(Feedback));

        public static readonly DependencyProperty CommentProperty = DependencyProperty.Register("Comment", typeof(string), typeof(Feedback));

        public static readonly DependencyProperty CommentHeadingProperty = DependencyProperty.Register("CommentHeading", typeof(string), typeof(Feedback),
            new FrameworkPropertyMetadata("Your comment is appreciated", FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.AffectsArrange | FrameworkPropertyMetadataOptions.AffectsMeasure));

        public CornerRadius CornerRadius {
            get { return (CornerRadius)GetValue(CornerRadiusProperty); }
            set { SetValue(CornerRadiusProperty, value); }
        }

        public object Header {
            get { return GetValue(HeaderProperty); }
            set { SetValue(HeaderProperty, value); }
        }

        public int Value {
            get { return (int)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        public string Comment {
            get { return (string)GetValue(CommentProperty); }
            set { SetValue(CommentProperty, value); }
        }

        public string CommentHeading {
            get { return (string)GetValue(CommentHeadingProperty); }
            set { SetValue(CommentHeadingProperty, value); }
        }

        #endregion

        #region Routed Events

        public static readonly RoutedEvent FeedbackSubmittedRoutedEvent =
            EventManager.RegisterRoutedEvent("FeedbackSubmitted", RoutingStrategy.Bubble, typeof(FeedbackSubmittedRoutedEventHandler), typeof(Feedback));

        public event FeedbackSubmittedRoutedEventHandler FeedbackSubmitted {
            add { AddHandler(FeedbackSubmittedRoutedEvent, value); }
            remove { RemoveHandler(FeedbackSubmittedRoutedEvent, value); }
        }

        protected void RaiseFeedbackSubmittedEvent(int value, string comment) {
            RaiseEvent(new FeedbackSubmittedRoutedEventArgs(Feedback.FeedbackSubmittedRoutedEvent, this, value, comment));
        }

        public static readonly RoutedEvent CancelRoutedEvent =
            EventManager.RegisterRoutedEvent("Cancel", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(Feedback));

        public event RoutedEventHandler Cancel {
            add { AddHandler(CancelRoutedEvent, value); }
            remove { RemoveHandler(CancelRoutedEvent, value); }
        }

        protected void RaiseCancel() {
            RaiseEvent(new RoutedEventArgs(Feedback.CancelRoutedEvent));
        }

        #endregion

        #region Static Constructor

        static Feedback() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Feedback), new FrameworkPropertyMetadata(typeof(Feedback)));
        }

        #endregion

        #region Methods

        public override void OnApplyTemplate() {
            base.OnApplyTemplate();

            _btnCancel = this.GetTemplateChild("PART_CancelButton") as Button;

            if (_btnCancel == null)
                throw new Exception("Template control PART_CancelButton was not found.");

            _btnSubmit = this.GetTemplateChild("PART_SubmitButton") as Button;

            if (_btnSubmit == null)
                throw new Exception("Template control PART_SubmitButton was not found.");

            _btnCancel.Click += new RoutedEventHandler(_btnCancel_Click);
            _btnSubmit.Click += new RoutedEventHandler(_btnSubmit_Click);

        }

        void _btnSubmit_Click(object sender, RoutedEventArgs e) {
            RaiseFeedbackSubmittedEvent(this.Value, this.Comment);
        }

        void _btnCancel_Click(object sender, RoutedEventArgs e) {
            RaiseCancel();
        }

        #endregion
    }
}
