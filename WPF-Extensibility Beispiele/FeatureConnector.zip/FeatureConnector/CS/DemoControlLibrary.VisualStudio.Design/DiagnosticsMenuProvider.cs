using System;
using Microsoft.Windows.Design.Features;
using Microsoft.Windows.Design.Interaction;

namespace DemoControlLibrary.VisualStudio.Design
{
    // The DiagnosticsMenuProvider class adds a context menu item
    // that displays a dialog box listing the currently running and 
    // pending feature connectors. 
    [FeatureConnector(typeof(DiagnosticsFeatureConnector))]
    public class DiagnosticsMenuProvider : PrimarySelectionContextMenuProvider 
    {
        public DiagnosticsMenuProvider() 
        {
            MenuAction action = new MenuAction("Feature Diagnostics...");

            action.Execute += new EventHandler<MenuActionEventArgs>(action_Execute); 

            Items.Add(action);
        }

        void action_Execute(object sender, MenuActionEventArgs e)
        {
            IDiagnosticsService service = 
                e.Context.Services.GetRequiredService<IDiagnosticsService>();

            service.ShowWindow();
        }
    }

    // The IDiagnosticsService specifies a simple interface for showing
    // a FeatureManagerDiagnostics window.
    interface IDiagnosticsService 
    {
        void ShowWindow();
    }

    // The DiagnosticsFeatureConnector publishes the IDiagnosticsService. 
    class DiagnosticsFeatureConnector : FeatureConnector<DiagnosticsMenuProvider>,
        IDiagnosticsService 
    {
        FeatureManagerDiagnostics fmdWindow;

        public DiagnosticsFeatureConnector(FeatureManager manager)
            : base(manager) 
        {
            Context.Services.Publish<IDiagnosticsService>(this);
        }

        #region IDiagnosticsService Members

        // The showWindow method creates a FeatureManagerDiagnostics
        // window and shows it.
        public void ShowWindow() 
        {
            if (fmdWindow != null) 
            {
                fmdWindow.Show();
                fmdWindow.Activate();
            }
            else 
            {
                fmdWindow = new FeatureManagerDiagnostics();
                fmdWindow.Initialize(Manager);
                fmdWindow.Closed += new EventHandler(fmdWindow_Closed); 
                fmdWindow.Show();
            }
        }

        void fmdWindow_Closed(object sender, EventArgs e)
        {
            fmdWindow = null; 
        }

        #endregion
    }
}
