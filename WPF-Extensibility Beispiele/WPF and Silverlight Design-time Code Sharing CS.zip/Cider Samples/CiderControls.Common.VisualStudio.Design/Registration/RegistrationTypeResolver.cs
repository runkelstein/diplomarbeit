﻿using System;
using Microsoft.Windows.Design.Metadata;

namespace CiderControls.Common.VisualStudio.Design.Registration {

    internal abstract class RegistrationTypeResolver {

        public abstract Type GetPlatformType(TypeIdentifier id);

    }
}
