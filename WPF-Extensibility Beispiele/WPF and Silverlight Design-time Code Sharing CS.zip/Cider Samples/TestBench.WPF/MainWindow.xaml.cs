﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TestBench.WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Feedback_FeedbackSubmitted(object sender, CiderControls.FeedbackSubmittedRoutedEventArgs e) {
            MessageBox.Show(string.Format("Thank you for voting: {0} and submitting this comment: {1}", e.Value, e.Comment));
        }

        private void Feedback_Cancel(object sender, RoutedEventArgs e) {
            MessageBox.Show("Send feedback later.");
        }

        private void feedback1_FeedbackSubmitted(object sender, CiderControls.FeedbackSubmittedRoutedEventArgs e) {

        }

    }
}
