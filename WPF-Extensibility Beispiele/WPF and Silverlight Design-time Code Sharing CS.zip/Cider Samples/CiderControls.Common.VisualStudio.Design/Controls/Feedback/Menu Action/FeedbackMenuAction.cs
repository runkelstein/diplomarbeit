﻿using Microsoft.Windows.Design.Interaction;

namespace CiderControls.Common.VisualStudio.Design.Controls {

    //TODO 16 - FeedbackMenuAction

    /// <summary>
    /// Class adds Value property to the MenuAction 
    /// </summary>
    internal class FeedbackMenuAction : MenuAction {

        private int _value;

        public FeedbackMenuAction(string displayName, int value)
            : base(displayName) {
            _value = value;
        }

        public int Value { get { return _value; } }
    }
}