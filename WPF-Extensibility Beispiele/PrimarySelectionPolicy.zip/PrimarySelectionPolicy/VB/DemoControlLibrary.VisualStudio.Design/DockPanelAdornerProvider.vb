Imports System
Imports System.Collections.Generic
Imports System.Windows
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Shapes

Imports Microsoft.Windows.Design.Interaction
Imports Microsoft.Windows.Design.Model
Imports Microsoft.Windows.Design.Policies

' The DockPanelAdornerProvider class implements an adorner
' that you can use to set the Margin property by using a 
' drag operation. The DockPanelPolicy class enables a 
' container policy for offering additional tasks and 
' adorners on the panel's children.
<UsesItemPolicy(GetType(DockPanelPolicy))>  _
Class DockPanelAdornerProvider
    Inherits AdornerProvider
    
    Public Sub New() 
        ' The adorner is a Rectangle element.
        Dim r As New Rectangle()
        r.Width = 23.0
        r.Height = 23.0
        r.Fill = AdornerColors.GlyphFillBrush

        ' Set the rectangle's placement in the adorner panel.
        AdornerPanel.SetAdornerHorizontalAlignment(r, AdornerHorizontalAlignment.OutsideLeft)
        AdornerPanel.SetAdornerVerticalAlignment(r, AdornerVerticalAlignment.OutsideTop)

        Dim p As New AdornerPanel()
        p.Children.Add(r)

        AdornerPanel.SetTask(r, New DockPanelMarginTask())

        Adorners.Add(p)
    End Sub
End Class
