﻿using System;
using System.Collections.Generic;
using System.Windows;
using CiderControls.Common.VisualStudio.Design.Infrastructure;
using CiderControls.Common.VisualStudio.Design.Resources;
using Microsoft.Windows.Design.Interaction;
using Microsoft.Windows.Design.Model;
using System.Diagnostics;

namespace CiderControls.Common.VisualStudio.Design.Controls {

    //TODO 17 - FeedbackControlContextMenuProvider
    // http://msdn.microsoft.com/en-us/library/microsoft.windows.design.interaction.primaryselectioncontextmenuprovider(VS.100).aspx

    /// <summary>
    /// Class provides the design time context menu.
    /// The FeedbackControl menu items
    /// Add a flyout
    ///    Feedback Set Value >   0
    ///                           1
    ///                           2
    ///                           3
    ///                           4
    ///                           5
    // The context menu lists the possible values for the Value property and allows setting the value using
    //   a checkable menu item.
    /// </summary>
    internal class FeedbackControlContextMenuProvider : PrimarySelectionContextMenuProvider {

        private MenuGroup _feedbackGroup;

        public FeedbackControlContextMenuProvider() {

            this.UpdateItemStatus += new EventHandler<MenuActionEventArgs>(FeedbackControlContextMenuProvider_UpdateItemStatus);

            //MenuGroup enables having submenus
            _feedbackGroup = new MenuGroup(Constants.STR_FEEDBACKGROUP, Strings.MenuFeedbackSetValue);
            _feedbackGroup.HasDropDown = true;

            // Add the 6 MenuActions
            for (int i = Constants.INT_MINIMUMRATINGVALUE; i < Constants.INT_MAXIMUMRATINGVALUE + 1; i++) {
                FeedbackMenuAction menuItem = new FeedbackMenuAction(Strings.ResourceManager.GetString(string.Format("MenuFeedbackSetValue{0}", i)), i);
                menuItem.Checkable = true;
                _feedbackGroup.Items.Add(menuItem);
                menuItem.Execute += new EventHandler<MenuActionEventArgs>(FeedbackSetValueMenuAction_Execute);
            }

            this.Items.Add(_feedbackGroup);
        }

        /// <summary>
        ///  When the menu item is clicked, set the value back into the model
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FeedbackSetValueMenuAction_Execute(object sender, MenuActionEventArgs e) {
            FeedbackMenuAction f = sender as FeedbackMenuAction;
            if (f != null) {

                try {

                    ModelItem ratingItem = e.Selection.PrimarySelection;

                    using (ModelEditingScope editingScope = ratingItem.BeginEdit(Strings.EditingContextDescription_Menu_SetFeedbackValue)) {
                        ModelProperty ratingValueProperty = ratingItem.Properties[MyPlatformTypes.Rating.ValueProperty];

                        Debug.Assert(ratingValueProperty != null, "ratingItem.Properties[MyPlatformTypes.Rating.ValueProperty] returned null");

                        if (ratingValueProperty != null) {
                            ratingValueProperty.SetValue(f.Value);
                            editingScope.Complete();
                        }
                    }

                }
                catch (Exception eX) {
                    MessageBox.Show(eX.ToString(), Strings.ExceptionMessageCaption_Exception_Writing_to_Cider, MessageBoxButton.OK, MessageBoxImage.Error, MessageBoxResult.OK);
                }
            }
        }

        /// <summary>
        /// UpdateItemStatus occurs when a menu about to be shown
        /// http://msdn.microsoft.com/en-us/library/microsoft.windows.design.interaction.contextmenuprovider.updateitemstatus.aspx
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FeedbackControlContextMenuProvider_UpdateItemStatus(object sender, MenuActionEventArgs e) {
            if (e.Selection.SelectionCount == 1 && e.Selection.PrimarySelection.IsItemOfType(MyPlatformTypes.Feedback.TypeId)) {
                int currentValue = 0;
                // grab the current computed value
                ModelItem ratingItem = e.Selection.PrimarySelection;
                ModelProperty ratingValueProperty = ratingItem.Properties[MyPlatformTypes.Rating.ValueProperty];

                Debug.Assert(ratingValueProperty != null, "ratingItem.Properties[MyPlatformTypes.Rating.ValueProperty] returned null");

                if (ratingValueProperty != null) {
                    object computedValue = ratingValueProperty.ComputedValue;
                    if (computedValue != null) {
                        currentValue = (int)computedValue;
                    }

                    // compare against all the items
                    foreach (FeedbackMenuAction item in _feedbackGroup.Items) {
                        item.Checked = (item.Value == currentValue);
                        item.Visible = true;
                    }
                }
            }
            else {
                // multiselect/non-feedback item
                foreach (MenuAction item in _feedbackGroup.Items) {
                    item.Visible = false;
                }
            }
        }
    }
}
