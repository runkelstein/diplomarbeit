using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using Microsoft.Windows.Design.Features;

namespace DemoControlLibrary.VisualStudio.Design
{
    // The FeatureManagerDiagnostics class implements a window
    // that displays the running and pending feature connectors.
    public partial class FeatureManagerDiagnostics : Window 
    {
        private FeatureManager featManager;

        public FeatureManagerDiagnostics() 
        {
            InitializeComponent();
        }

        public void Initialize(FeatureManager manager) 
        {
            featManager = manager;
            Bind();
        }

        private void OnRefreshClick(object sender, RoutedEventArgs e) 
        {
            Bind();
        }

        // Binds the activatedFeatures and pendingFeatures controls
        // the FeatureManager's RunningConnectors and PendingConnectors\
        // properties.
        private void Bind() 
        {
            activatedFeatures.Items.Clear();
            pendingFeatures.Items.Clear();

            foreach (FeatureConnectorInformation info in 
                featManager.RunningConnectors) 
            {
                activatedFeatures.Items.Add(info);
            }

            foreach (FeatureConnectorInformation info in 
                featManager.PendingConnectors) 
            {
                pendingFeatures.Items.Add(info);
            }
        }
    }
}
