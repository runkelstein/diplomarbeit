﻿using System;

namespace CiderControls {

    public class FeedbackSubmittedEventArgs : EventArgs {

        #region Properites

        public int Value { get; set; }
        public string Comment { get; set; }

        #endregion

        #region Constructors

        public FeedbackSubmittedEventArgs(int value, string comment)
            : base() {

            Value = value;
            Comment = comment;
        }

        #endregion
    }
}
