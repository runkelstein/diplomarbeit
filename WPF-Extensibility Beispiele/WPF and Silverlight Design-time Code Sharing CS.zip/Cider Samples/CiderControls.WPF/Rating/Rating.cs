﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Shapes;
using System.ComponentModel;

namespace CiderControls {

    [TemplatePart(Name = "PART_LayoutGrid", Type = typeof(Grid))]
    public class Rating : Control {

        #region Declarations

        private Grid _layoutGrid;
        private const int _minValue = 1;
        private const int _maxValue = 5;
        private const int _unSetValue = 0;

        #endregion

        #region Events

        public event EventHandler<ValueSelectedEventArgs> ValueSelected;

        protected virtual void OnValueSelected() {
            if (ValueSelected != null)
                ValueSelected(this, new ValueSelectedEventArgs(this.Value));
        }

        #endregion

        #region Dependency Properties

        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register("Value", typeof(int), typeof(Rating),
            new PropertyMetadata( _unSetValue, new PropertyChangedCallback(OnValueChanged), new CoerceValueCallback(ValueCoerceValue)), new ValidateValueCallback(ValueValidateCallback));

        public int Value {
            get { return (int)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        private static void OnValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
            Rating r = (Rating)d;
            r.RenderValue((int)e.NewValue);
        }
        
        private static object ValueCoerceValue(DependencyObject d, object value) {
            int intTest = (int)d.GetValue(ValueProperty);
            if (intTest < _unSetValue) {
                return _unSetValue;
            }
            else if (intTest > _maxValue) {
                return _maxValue;
            }

            return value;
        }

        private static bool ValueValidateCallback(object value) {
            int intTest = (int)value;
            if (intTest < _unSetValue) {
                return false;
            }
            else if (intTest > _maxValue) {
                return false;
            }

            return true;
        }

        #endregion

        #region Constructors

        public Rating() {
            this.Loaded += new RoutedEventHandler(Rating_Loaded);
        }


        static Rating() {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Rating), new FrameworkPropertyMetadata(typeof(Rating)));
        }

        #endregion

        #region Methods

        public override void OnApplyTemplate() {
            base.OnApplyTemplate();

            _layoutGrid = this.GetTemplateChild("PART_LayoutGrid") as Grid;

            if (_layoutGrid == null)
                throw new Exception("Template control PART_LayoutGrid was not found.");

        }

        void Rating_Loaded(object sender, RoutedEventArgs e) {

            _layoutGrid.MouseLeave += new MouseEventHandler(_layoutGrid_MouseLeave);

            Ellipse ellp;

            for (int intX = _minValue; intX <= _maxValue; intX++) {
                _layoutGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(18) });
                ellp = new Ellipse { Tag = intX, Style = this.FindResource("unsetEllipseStyle") as Style };
                ellp.SetValue(Grid.ColumnProperty, intX - 1);
                ellp.MouseEnter += new MouseEventHandler(ellp_MouseEnter);
                ellp.MouseDown += new MouseButtonEventHandler(ellp_MouseDown);
                ellp.ToolTip = "Click to set value.  If already set, clicking will set value to zero.";
                _layoutGrid.Children.Add(ellp);
            }

            RenderValue(this.Value);
        }

        void ellp_MouseDown(object sender, MouseButtonEventArgs e) {
            Ellipse ellp = (Ellipse)sender;
            int value = (int)ellp.Tag;
            if (value != this.Value) {
                this.Value = (int)ellp.Tag;
                OnValueSelected();
                e.Handled = true;
            } else {
                this.Value = _unSetValue;
                OnValueSelected();
                e.Handled = true;
            }
        }

        void ellp_MouseEnter(object sender, MouseEventArgs e) {
            Ellipse ellp = (Ellipse)sender;
            int value = (int)ellp.Tag;
            RenderValue(value);
            e.Handled = true;
        }

        void _layoutGrid_MouseLeave(object sender, MouseEventArgs e) {
            RenderValue(this.Value);
            e.Handled = true;
        }

        void RenderValue(int value) {
            if (_layoutGrid == null || _layoutGrid.Children == null)
                return;

            foreach (Ellipse elp in _layoutGrid.Children) {
                if ((int)elp.Tag <= value) {
                    elp.Style = this.FindResource("setEllipseStyle") as Style;
                }
                else {
                    elp.Style = this.FindResource("unsetEllipseStyle") as Style;
                }
            }
        }

        #endregion
    }
}
