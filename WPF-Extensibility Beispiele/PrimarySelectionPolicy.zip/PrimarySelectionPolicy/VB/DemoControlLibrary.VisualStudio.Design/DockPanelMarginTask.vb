Imports System
Imports System.Collections.Generic
Imports System.Windows
Imports System.Windows.Input

Imports Microsoft.Windows.Design.Interaction

' A DockPanelMarginTask is attached to to the adorner
' offered by the DockPanelAdornerProvider class. When 
' you drag the adorner, the target control's Margin
' property changes. 
Class DockPanelMarginTask
    Inherits Task

    Private dragBinding, endDragBinding As InputBinding
    Private initialMargin As Thickness

    ' The DockPanelMarginTask constructor establishes mappings 
    ' between user inputs and commands. 
    Public Sub New() 
        Dim beginDrag As New ToolCommand("BeginDrag")
        Dim drag As New ToolCommand("Drag")
        Dim endDrag As New ToolCommand("EndDrag")
        Dim resetMargins As New ToolCommand("ResetMargins")
        
        Me.InputBindings.Add(New InputBinding( _
            beginDrag, _
            New ToolGesture(ToolAction.DragIntent, MouseButton.Left)))
        
        Me.InputBindings.Add( _
            New InputBinding( _
                resetMargins, _
                New ToolGesture(ToolAction.DoubleClick, MouseButton.Left)))
        
        Me.dragBinding = New InputBinding( _
            drag, _
            New ToolGesture(ToolAction.Move))
        
        Me.endDragBinding = New InputBinding( _
            endDrag, _
            New ToolGesture(ToolAction.DragComplete))
        
        Me.ToolCommandBindings.Add(New ToolCommandBinding(beginDrag, AddressOf OnBeginDrag))
        Me.ToolCommandBindings.Add(New ToolCommandBinding(drag, AddressOf OnDrag))
        Me.ToolCommandBindings.Add(New ToolCommandBinding(endDrag, AddressOf OnEndDrag))
        Me.ToolCommandBindings.Add(New ToolCommandBinding(resetMargins, AddressOf OnResetMargins))
    
    End Sub

    Private Sub OnBeginDrag(ByVal sender As Object, ByVal args As ExecutedToolEventArgs) 
        Dim data As GestureData = GestureData.FromEventArgs(args)
        
        Me.BeginFocus(data)
        Me.InputBindings.Add(dragBinding)
        Me.InputBindings.Add(endDragBinding)
        
        Me.initialMargin = CType(data.ImpliedSource.Properties("Margin").ComputedValue, Thickness)
    
    End Sub

    Private Sub OnDrag(ByVal sender As Object, ByVal args As ExecutedToolEventArgs) 
        Dim data As MouseGestureData = MouseGestureData.FromEventArgs(args)
        Dim offX As Double = data.PositionDelta.X
        Dim offY As Double = data.PositionDelta.Y
        
        Dim newMargin As Thickness = initialMargin
        
        newMargin.Bottom += offY
        newMargin.Top += offY
        newMargin.Left += offX
        newMargin.Right += offX
        
        data.ImpliedSource.Properties("Margin").SetValue(newMargin)
    
    End Sub

    Private Sub OnEndDrag(ByVal sender As Object, ByVal args As ExecutedToolEventArgs) 
        Description = "Adjust margin"
        Me.Complete()
    
    End Sub

    Protected Overrides Sub OnCompleted(ByVal e As EventArgs) 
        Me.Cleanup()
        MyBase.OnCompleted(e)
    
    End Sub

    Protected Overrides Sub OnReverted(ByVal e As EventArgs) 
        Me.Cleanup()
        MyBase.OnReverted(e)
    
    End Sub

    Private Sub Cleanup() 
        Me.InputBindings.Remove(dragBinding)
        Me.InputBindings.Remove(endDragBinding)
    
    End Sub

    Private Sub OnResetMargins(ByVal sender As Object, ByVal args As ExecutedToolEventArgs) 
        Dim data As GestureData = GestureData.FromEventArgs(args)
        data.ImpliedSource.Properties("Margin").ClearValue()
    
    End Sub
End Class
