using System;
using System.Collections.Generic;

using Microsoft.Windows.Design.Model;
using Microsoft.Windows.Design.Policies;

namespace DemoControlLibrary.VisualStudio.Design
{
    // The DockPanelPolicy class implements a surrogate policy that
    // provides container semantics for a selected item. By using 
    // this policy, the DemoDockPanel container control offers 
    // additional tasks and adorners on its children. 
    class DockPanelPolicy : PrimarySelectionPolicy 
    {
        public override bool IsSurrogate 
        {
            get 
            { 
                return true;
            }
        }

        public override IEnumerable<ModelItem> GetSurrogateItems(ModelItem item) 
        {
            ModelItem parent = item.Parent;
            
            if (parent != null)
            {
                yield return parent;
            }
        }
    }
}
