﻿using System;
using System.Windows;
using CiderControls.Common.VisualStudio.Design.Infrastructure;

namespace CiderControls.Common.VisualStudio.Design.Controls {

    //TODO 13 - RatingEditorResourceDictionary

    /// <summary>
    ///  The RatingSelector property supplies a strong typed access to the RateSelectorTemplate DataTemplate
    ///    in the RatingEditorResourceDictionary.xaml file.
    ///    
    /// This class implements the Singleton pattern so that the resource dictionary is only created once
    /// and is accessed through the Instance property.
    /// </summary>
    internal partial class RatingEditorResourceDictionary : ResourceDictionary {

        [ThreadStatic]
        private static RatingEditorResourceDictionary _instance;

        private RatingEditorResourceDictionary() {
            InitializeComponent();
        }

        /// <summary>
        /// return a cached copy of the resource dictionary
        /// </summary>
        internal static RatingEditorResourceDictionary Instance {
            get {
                if (_instance == null) {
                    _instance = new RatingEditorResourceDictionary();
                }
                return _instance;
            }
        }

        /// <summary>
        /// DataTemplate for the RatingEditor
        /// </summary>
        public DataTemplate RatingSelector {
            get {
                return this[Constants.STR_RATESELECTORTEMPLATE] as DataTemplate;
            }
        }
    }
}
