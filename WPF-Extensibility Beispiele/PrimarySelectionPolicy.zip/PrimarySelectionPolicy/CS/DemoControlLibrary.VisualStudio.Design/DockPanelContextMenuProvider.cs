using System;
using System.Windows.Controls;

using Microsoft.Windows.Design.Interaction;
using Microsoft.Windows.Design.Metadata;
using Microsoft.Windows.Design.Model;
using Microsoft.Windows.Design.Policies;
using System.Windows;

namespace DemoControlLibrary.VisualStudio.Design
{
    // The DockPanelContextMenuProvider class implements a 
    // context menu group for setting the Dock property of
    // the target control. The menu feature provider is bound to 
    // a policy that enables a context menu for children of 
    // a DemoDockPanel.
    [UsesItemPolicy(typeof(DockPanelPolicy))]
    class DockPanelContextMenuProvider : ContextMenuProvider 
    {
        MenuAction lastFill;

        public DockPanelContextMenuProvider() 
        {
            // Create and populate the menu group.
            MenuGroup group = new MenuGroup("Dock", "Dock");
            group.Items.Add(new DockMenuAction(Dock.Left));
            group.Items.Add(new DockMenuAction(Dock.Right));
            group.Items.Add(new DockMenuAction(Dock.Top));
            group.Items.Add(new DockMenuAction(Dock.Bottom));

            lastFill = new MenuAction("Last Child Fill");
            lastFill.Checkable = true;
            lastFill.Execute += 
                new EventHandler<MenuActionEventArgs>(lastFill_Execute);
            group.Items.Add(lastFill);

            UpdateItemStatus += 
                new EventHandler<MenuActionEventArgs>(
                    DockPanelContextMenu_UpdateItemStatus);

            // The group appears in a flyout menu.
            group.HasDropDown = true;

            Items.Add(group);
        }

        void DockPanelContextMenu_UpdateItemStatus(
            object sender, 
            MenuActionEventArgs e)
        {
            ModelItem parent = e.Selection.PrimarySelection.Parent;
            bool check = (bool)parent.Properties["LastChildFill"].ComputedValue;
            lastFill.Checked = check;
        }

        void lastFill_Execute(object sender, MenuActionEventArgs e)
        {
            ModelItem parent = e.Selection.PrimarySelection.Parent;
            if (lastFill.Checked)
            {
                parent.Properties["LastChildFill"].ClearValue();
            }
            else
            {
                parent.Properties["LastChildFill"].SetValue(lastFill.Checked);
            }
        }

        private class DockMenuAction : MenuAction 
        {   
            private Dock dockValue;

            internal DockMenuAction(Dock value) : base(value.ToString()) 
            {
                dockValue = value;
                Execute += OnExecute;
            }

            private void OnExecute(object sender, MenuActionEventArgs args) 
            {
                PropertyIdentifier pi = new PropertyIdentifier( typeof( DockPanel ), "Dock" );
                ModelItem item = args.Selection.PrimarySelection;
                item.Properties[pi].SetValue(dockValue);
            }
        }
    }
}
