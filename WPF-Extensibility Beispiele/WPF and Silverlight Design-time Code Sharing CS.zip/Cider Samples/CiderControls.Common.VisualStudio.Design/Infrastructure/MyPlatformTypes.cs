﻿using Microsoft.Windows.Design.Metadata;

namespace CiderControls.Common.VisualStudio.Design.Infrastructure {

    //TODO  8 - Platform independent type and property references.

    /// <summary>
    ///  Enables the creation and manipulation of types and properties via the Model without a direct reference to Silverlight. 
    ///  This allows:
    ///    (1) the design time implementation to cleanly use WPF to implement any design time UI
    ///    (2) allows the design time to target both WPF and Silverlight if required
    /// </summary>
    internal class MyPlatformTypes {

        public class Feedback : Control {
            new public static readonly TypeIdentifier TypeId = new TypeIdentifier("CiderControls.Feedback");
            public static readonly PropertyIdentifier HeaderProperty = new PropertyIdentifier(TypeId, "Header");
            public static readonly PropertyIdentifier ValueProperty = new PropertyIdentifier(TypeId, "Value");
            public static readonly PropertyIdentifier CornerRadiusProperty = new PropertyIdentifier(TypeId, "CornerRadius");
        }

        public class Control {
            public static readonly TypeIdentifier TypeId = new TypeIdentifier("http://schemas.microsoft.com/winfx/2006/xaml/presentation", "Control");
            public static readonly PropertyIdentifier BorderBrushProperty = new PropertyIdentifier(TypeId, "BorderBrush");
            public static readonly PropertyIdentifier BorderThicknessProperty = new PropertyIdentifier(TypeId, "BorderThickness");
        }

        public class Rating {
            public static readonly TypeIdentifier TypeId = new TypeIdentifier("CiderControls.Rating");
            public static readonly PropertyIdentifier ValueProperty = new PropertyIdentifier(TypeId, "Value");
        }
    }
}
