﻿using System;
using System.ComponentModel;
using CiderControls.Common.VisualStudio.Design.Controls;
using CiderControls.Common.VisualStudio.Design.Infrastructure;
using Microsoft.Windows.Design.Features;
using Microsoft.Windows.Design.Metadata;
using Microsoft.Windows.Design.PropertyEditing;
using Microsoft.Windows.Design;

//
// This should be in AssemblyInfo.cs - declaring here to make it obvious
//

[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("CiderControls.WPF.VisualStudio.Design")]
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("CiderControls.Silverlight.VisualStudio.Design")]

namespace CiderControls.Common.VisualStudio.Design.Registration {

    //TODO  5 - CiderControlsAttributeTableBuilder

    /// <summary>
    /// Platform neutral class that builds platform specific metadata
    /// </summary>
    internal class CiderControlsAttributeTableBuilder : AttributeTableBuilder {

        #region Declarations

        // allows for Platform specific Types to be used without directly referencing Silverlight
        private RegistrationTypeResolver _registrationTypeResolver;

        #endregion

        #region Constructor

        //TODO  6 - registrationTypeResolver resolves the platform specific Types in the platform neutral metadata builder

        public CiderControlsAttributeTableBuilder(RegistrationTypeResolver registrationTypeResolver) {
            _registrationTypeResolver = registrationTypeResolver;

            AddFeedbackControlAttributes();
            AddRatingControlAttributes();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Builds Feedback control metedata
        /// </summary>
        private void AddFeedbackControlAttributes() {

            //TODO  7 - Resolve the Platform specific Feedback control from the platform neutral TypeIdentifier
            Type feebackType = _registrationTypeResolver.GetPlatformType(MyPlatformTypes.Feedback.TypeId);

            //TODO  9 - Using the above feedbackType, create platform specific metadata for the Feedback control
            // the below code adds features, catetory editor, inline editor, type converter and 
            //    assigns a Category to each Feedback control property

            AddTypeAttributes(feebackType,
                new FeatureAttribute(typeof(FeedbackControlInitializer)),
                new FeatureAttribute(typeof(FeedbackControlContextMenuProvider)),
                new FeatureAttribute(typeof(FeedbackControlAdornerProvider))
                );

            AddCategoryEditor(feebackType,
                typeof(FeedbackControlCategoryEditor));

            AddMemberAttributes(feebackType,
                Constants.STR_CORNERRADIUS,
                new CategoryAttribute(Constants.STR_COMMON));

            // since the below Header property is of type object, it requires this 
            // StringConverter to enable editing of simple string values in the properties window.
            AddMemberAttributes(feebackType,
                Constants.STR_HEADER,
                new CategoryAttribute(Constants.STR_CUSTOM),
                new TypeConverterAttribute(typeof(StringConverter)));

            AddMemberAttributes(feebackType,
                Constants.STR_VALUE,
                new CategoryAttribute(Constants.STR_CUSTOM),
                PropertyValueEditor.CreateEditorAttribute(typeof(RatingSelectorInlineEditor)));

            AddMemberAttributes(feebackType,
                Constants.STR_COMMENT,
                new CategoryAttribute(Constants.STR_CUSTOM));

            AddMemberAttributes(feebackType,
                Constants.STR_COMMENTHEADING,
                new CategoryAttribute(Constants.STR_CUSTOM));

        }

        /// <summary>
        /// Builds Rating control metedata
        /// </summary>
        private void AddRatingControlAttributes() {

            //TODO  7.1 - Resolve the Platform specific Rating control from the platform neutral TypeIdentifier
            Type ratingType = _registrationTypeResolver.GetPlatformType(MyPlatformTypes.Rating.TypeId);

            //TODO  9.1 - Using the above ratingType, create platform specific metadata for the Rating control
            // the below code keeps the Rating control from appearing in the Choose Items dialog after the
            //   the CiderControls.WPF or CiderControls.Siverlight assembly is added.
            //
            // this is only done for illustration, there is no actual reason to keep the Rating control out of the
            //   Choose Items dialog.
            AddTypeAttributes(ratingType,
                ToolboxBrowsableAttribute.No
                );
        }

        #endregion

        #region Add Metadata Helpers

        private void AddTypeAttributes(Type type, params Attribute[] attribs) {
            base.AddCallback(type, builder => builder.AddCustomAttributes(attribs));
        }

        private void AddCategoryEditor(Type type, Type editorType) {
            base.AddCallback(type, builder => builder.AddCustomAttributes(CategoryEditor.CreateEditorAttribute(editorType)));
        }

        private void AddMemberAttributes(Type type, string memberName, params Attribute[] attribs) {
            base.AddCallback(type, builder => builder.AddCustomAttributes(memberName, attribs));
        }

        #endregion
    }
}
