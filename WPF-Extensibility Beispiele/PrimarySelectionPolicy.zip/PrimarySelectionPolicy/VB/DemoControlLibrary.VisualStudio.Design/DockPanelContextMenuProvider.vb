Imports System
Imports System.Windows.Controls

Imports Microsoft.Windows.Design.Interaction
Imports Microsoft.Windows.Design.Model
Imports Microsoft.Windows.Design.Policies
Imports System.Windows
Imports Microsoft.Windows.Design.Metadata


' The DockPanelContextMenuProvider class implements a 
' context menu group for setting the Dock property of
' the target control. The menu feature provider is bound to 
' a policy that enables a context menu for children of 
' a DemoDockPanel.
<UsesItemPolicy(GetType(DockPanelPolicy))> _
Class DockPanelContextMenuProvider
    Inherits ContextMenuProvider

    Private lastFill As MenuAction

    Public Sub New()
        ' Create and populate the menu group.
        Dim group As New MenuGroup("Dock", "Dock")
        group.Items.Add(New DockMenuAction(Dock.Left))
        group.Items.Add(New DockMenuAction(Dock.Right))
        group.Items.Add(New DockMenuAction(Dock.Top))
        group.Items.Add(New DockMenuAction(Dock.Bottom))

        lastFill = New MenuAction("Last Child Fill")
        lastFill.Checkable = True
        AddHandler lastFill.Execute, AddressOf lastFill_Execute

        group.Items.Add(lastFill)

        AddHandler UpdateItemStatus, AddressOf DockPanelContextMenu_UpdateItemStatus

        ' The group appears in a flyout menu.
        group.HasDropDown = True

        Items.Add(group)

    End Sub

    Sub DockPanelContextMenu_UpdateItemStatus(ByVal sender As Object, ByVal e As MenuActionEventArgs)
        Dim parent As ModelItem = e.Selection.PrimarySelection.Parent
        Dim check As Boolean = CBool(parent.Properties("LastChildFill").ComputedValue)
        lastFill.Checked = check

    End Sub

    Sub lastFill_Execute(ByVal sender As Object, ByVal e As MenuActionEventArgs)
        Dim parent As ModelItem = e.Selection.PrimarySelection.Parent
        If lastFill.Checked Then
            parent.Properties("LastChildFill").ClearValue()
        Else
            parent.Properties("LastChildFill").SetValue(lastFill.Checked)
        End If

    End Sub

    Private Class DockMenuAction
        Inherits MenuAction
        Private dockValue As Dock


        Friend Sub New(ByVal value As Dock)
            MyBase.New(value.ToString())
            dockValue = value
            AddHandler Execute, AddressOf OnExecute

        End Sub


        Private Sub OnExecute(ByVal sender As Object, ByVal args As MenuActionEventArgs)
            Dim pi As New PropertyIdentifier(GetType(DockPanel), "Dock")
            Dim item As ModelItem = args.Selection.PrimarySelection
            item.Properties(pi).SetValue(dockValue)

        End Sub
    End Class
End Class
