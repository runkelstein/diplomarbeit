﻿using CiderControls.Common.VisualStudio.Design.Infrastructure;
using Microsoft.Windows.Design.Model;

namespace CiderControls.Common.VisualStudio.Design.Controls {

    //TODO 14 - FeedbackControlInitializer
    //  http://msdn.microsoft.com/en-us/library/microsoft.windows.design.model.defaultinitializer(VS.100).aspx

    /// <summary>
    /// An initializer is called during control creation on the design surface
    /// You can set properties on the ModelItem to adjust the default values.
    /// </summary>
    internal class FeedbackControlInitializer : DefaultInitializer {

        public FeedbackControlInitializer() {
        }

        /// <summary>
        /// Callback when the designer has created the FeedbackControl.
        /// </summary>
        public override void InitializeDefaults(ModelItem item) {
            base.InitializeDefaults(item);
            // The below values are set demonstration purposes to show how its done.
            // See how nice the platform neutral PropertyIdentifiers work.  
            // ex: MyPlatformTypes.Feedback.CornerRadiusProperty
            item.Properties[MyPlatformTypes.Feedback.CornerRadiusProperty].SetValue("10");
            item.Properties[MyPlatformTypes.Feedback.BorderThicknessProperty].SetValue("2");
            item.Properties[MyPlatformTypes.Feedback.BorderBrushProperty].SetValue("LightGray");
        }
    }
}
