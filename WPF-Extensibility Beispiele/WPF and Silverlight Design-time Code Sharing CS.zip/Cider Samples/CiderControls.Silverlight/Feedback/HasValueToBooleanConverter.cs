﻿using System;
using System.Windows.Data;

namespace CiderControls {

    public class HasValueToBooleanConverter : IValueConverter {

        object IValueConverter.Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture) {
            if (value != null && value is int) {
                int i = (int)value;
                int p = 0;

                if (parameter != null && parameter is int)
                    p = (int)parameter;

                if (i > p) {
                    return true;
                }
            }
            return false;
        }

        object IValueConverter.ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture) {
            throw new NotImplementedException();
        }
    }
}
