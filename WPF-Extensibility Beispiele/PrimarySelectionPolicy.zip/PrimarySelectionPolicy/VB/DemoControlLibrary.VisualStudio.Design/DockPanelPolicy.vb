Imports System
Imports System.Collections.Generic

Imports Microsoft.Windows.Design.Model
Imports Microsoft.Windows.Design.Policies

' The DockPanelPolicy class implements a surrogate policy that
' provides container semantics for a selected item. By using 
' this policy, the DemoDockPanel container control offers 
' additional tasks and adorners on its children. 
Class DockPanelPolicy
    Inherits PrimarySelectionPolicy
    
    Public Overrides ReadOnly Property IsSurrogate() As Boolean 
        Get
            Return True
        End Get
    End Property
    
    Public Overrides Function GetSurrogateItems( _
        ByVal item As Microsoft.Windows.Design.Model.ModelItem) _
        As System.Collections.Generic.IEnumerable( _
        Of Microsoft.Windows.Design.Model.ModelItem)

        Dim parent As ModelItem = item.Parent

        Dim e As New System.Collections.Generic.List(Of ModelItem)

        If (parent IsNot Nothing) Then

            e.Add(parent)

        End If

        Return e

    End Function

End Class
