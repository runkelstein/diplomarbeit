using System;
using System.Windows;

namespace DemoControlLibrary
{
    // The DemoDockPanel control provides a DockPanel that
    // has custom design-time behavior. 
    public class DemoDockPanel : System.Windows.Controls.DockPanel 
    {

    }
}
