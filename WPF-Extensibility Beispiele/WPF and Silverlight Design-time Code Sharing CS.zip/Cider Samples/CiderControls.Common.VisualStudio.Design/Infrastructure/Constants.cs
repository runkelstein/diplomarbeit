﻿
namespace CiderControls.Common.VisualStudio.Design.Infrastructure {

    /// <summary>
    /// Assembly constants
    /// </summary>
    internal static class Constants {

        public const int INT_MINIMUMRATINGVALUE = 0;
        public const int INT_MAXIMUMRATINGVALUE = 5;
        public const string STR_CIDERCONTROLSFEEDBACK = "CiderControls.Feedback";
        public const string STR_CIDERCONTROLSRATING = "CiderControls.Rating";
        public const string STR_FEEDBACKGROUP = "FeedbackGroup";
        public const string STR_VALUE = "Value";
        public const string STR_CUSTOM = "Custom";
        public const string STR_COMMON = "Common";
        public const string STR_CORNERRADIUS = "CornerRadius";
        public const string STR_HEADER = "Header";
        public const string STR_COMMENT = "Comment";
        public const string STR_COMMENTHEADING = "CommentHeading";
        public const string STR_RATESELECTORTEMPLATE = "RateSelectorTemplate";
        public const string STR_FEEDBACKCATEGORYEDITORTEMPLATE = "FeedbackCategoryEditorTemplate";
        public const string STR_MULTILINETEXTEDITORTEMPLATE = "MultilineTextEditorTemplate";

    }
}
