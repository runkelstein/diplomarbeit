using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

using Microsoft.Windows.Design.Interaction;
using Microsoft.Windows.Design.Model;
using Microsoft.Windows.Design.Policies;

namespace DemoControlLibrary.VisualStudio.Design
{
    // The DockPanelAdornerProvider class implements an adorner
    // that you can use to set the Margin property by using a 
    // drag operation. The DockPanelPolicy class enables a 
    // container policy for offering additional tasks and 
    // adorners on the panel's children.
    [UsesItemPolicy(typeof(DockPanelPolicy))]
    class DockPanelAdornerProvider : AdornerProvider
    {
        public DockPanelAdornerProvider() 
        {
            // The adorner is a Rectangle element.
            Rectangle r = new Rectangle();
            r.Width = 23.0;
            r.Height = 23.0;
            r.Fill = AdornerColors.GlyphFillBrush;

            // Set the rectangle's placement in the adorner panel.
            AdornerPanel.SetAdornerHorizontalAlignment(r, AdornerHorizontalAlignment.OutsideLeft);
            AdornerPanel.SetAdornerVerticalAlignment(r, AdornerVerticalAlignment.OutsideTop);
            
            AdornerPanel p = new AdornerPanel();
            p.Children.Add(r);

            AdornerPanel.SetTask(r, new DockPanelMarginTask());

            Adorners.Add(p);
        }
    } 
}
