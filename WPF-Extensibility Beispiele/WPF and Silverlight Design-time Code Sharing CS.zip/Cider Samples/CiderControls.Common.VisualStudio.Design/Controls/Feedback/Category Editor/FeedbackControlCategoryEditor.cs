﻿using System.Windows;
using CiderControls.Common.VisualStudio.Design.Infrastructure;
using Microsoft.Windows.Design.PropertyEditing;

namespace CiderControls.Common.VisualStudio.Design.Controls {

    //TODO 13 - FeedbackControlCategoryEditor
    // http://msdn.microsoft.com/en-us/library/microsoft.windows.design.propertyediting.categoryeditor(VS.100).aspx

    /// <summary>
    /// A category editor is a group of properties that can be edited together.
    /// 
    /// The Text and Brushes category editors are examples of a category editor.
    /// The Text category editor consumes all the Text related properties and 
    /// displays them in a complex UI.  The brush category editor consumes all the 
    /// properties of type brush, displays UI and a list of properties to manipulate.
    /// </summary>
    internal class FeedbackControlCategoryEditor : CategoryEditor {

        public FeedbackControlCategoryEditor() {
        }

        /// <summary>
        /// Provides ability to list or not list properties by name in a category.
        /// </summary>
        /// <param name="propertyEntry"></param>
        /// <returns>return true if the property is edited by this category editor.
        /// Returning false will cause the property to be listed as a separate row 
        /// within the category.</returns>
        public override bool ConsumesProperty(PropertyEntry propertyEntry) {
            return true;
        }

        /// <summary>
        /// Caegory editor data template
        /// </summary>
        public override DataTemplate EditorTemplate {
            get {
                return FeedbackControlResourceDictionary.Instance.FeedbackCategoryEditor;
            }
        }

        /// <summary>
        /// Used by Blend only
        /// http://msdn.microsoft.com/en-us/library/microsoft.windows.design.propertyediting.categoryeditor.getimage(VS.100).aspx
        /// </summary>
        /// <param name="desiredSize"></param>
        /// <returns></returns>
        public override object GetImage(Size desiredSize) {
            return null;
        }

        /// <summary>
        /// Defines the category this category editor is for.
        /// </summary>
        public override string TargetCategory {
            get { return Constants.STR_CUSTOM; }
        }
    }
}
