﻿using System;
using CiderControls.Common.VisualStudio.Design.Infrastructure;
using CiderControls.Common.VisualStudio.Design.Registration;
using Microsoft.Windows.Design.Metadata;

namespace CiderControls.WPF.VisualStudio.Design {

    //TODO  4 - WPF - WPFTypeResolver

    /// <summary>
    /// WPF type resolver
    /// </summary>
    internal class WPFTypeResolver : RegistrationTypeResolver {

        /// <summary>
        /// Takes a platform neutral TypeIdentifier and returns back a platform specific Type.
        ///  For each of the types you are providing a design experience for, you must add an entry to this method.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public override Type GetPlatformType(TypeIdentifier id) {
            switch (id.Name) {

                case Constants.STR_CIDERCONTROLSFEEDBACK:
                    return typeof(CiderControls.Feedback);

                case Constants.STR_CIDERCONTROLSRATING:
                    return typeof(CiderControls.Rating);
            }

            throw new ArgumentOutOfRangeException("id.Name", id.Name, CiderControls.Common.VisualStudio.Design.Resources.Strings.ExceptionMessageValue_not_programmed);
        }
    }
}
