using System;
using System.Windows;

namespace DemoControlLibrary
{
    // The DemoButton control provides a button that
    // has custom design-time behavior. 
    public class DemoButton : System.Windows.Controls.Button 
    {

    }
}
