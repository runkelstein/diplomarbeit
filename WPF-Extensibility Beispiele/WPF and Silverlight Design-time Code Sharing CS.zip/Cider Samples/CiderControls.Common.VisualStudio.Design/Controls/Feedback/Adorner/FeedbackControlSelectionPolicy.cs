﻿using Microsoft.Windows.Design.Interaction;
using Microsoft.Windows.Design.Model;
using Microsoft.Windows.Design.Policies;

namespace CiderControls.Common.VisualStudio.Design.Controls {

    //TODO 11 - FeedbackControlSelectionPolicy

    /// <summary>
    /// This FeedbackControlSelectionPolicy provides for hiding of the adorner when the
    /// Feedback control is being resized or moved. 
    /// </summary>
    internal class FeedbackControlSelectionPolicy : PrimarySelectionPolicy {

        private bool _isFocused;

        public FeedbackControlSelectionPolicy() {
        }

        /// <summary>
        /// Determines if an item is part of the policy.  Called back from 
        /// OnPolicyItemsChanged on all the items in e.ItemsAdded 
        /// </summary>
        /// <param name="selection"></param>
        /// <param name="item"></param>
        /// <returns></returns>
        protected override bool IsInPolicy(Selection selection, ModelItem item) {
            bool inPolicy = base.IsInPolicy(selection, item);
            return inPolicy && !_isFocused;
        }

        /// <summary>
        /// Called when this policy is activated.  In order to determine 
        /// which items are in/out of a policy, we need to subscribe to events.
        /// The base class, PrimarySelectionPolicy, subscribes to 
        /// changes in selection.  Additionally we need to subscribe to changes
        /// in the focused task so we can disable during resize/move.
        /// </summary>
        protected override void OnActivated() {
            this.Context.Items.Subscribe<FocusedTask>(OnFocusedTaskChanged);
            base.OnActivated();
        }

        /// <summary>
        /// When the policy is no longer in use, we unsubscribe from the events we hooked up to in Activated.
        /// </summary>        
        protected override void OnDeactivated() {
            this.Context.Items.Unsubscribe<FocusedTask>(OnFocusedTaskChanged);
            base.OnDeactivated();
        }

        // If the Feedback control is selected and there is a FocusedTask like moving or resizing the control,
        //   the Feedback control will be added to the Removed parameter and the adorner
        //   will be removed from the Feeback control.
        // During the drag or resize operation this code will be bypassed on repeated calls until
        //   the move or resize is completed.

        // If the Feedback control is selected and there is no FocusedTask like moving or being resized,
        //   the Feedback control will be added to the Added parameter and the adorner
        //   will be shown on the Feedback control.

        /// <summary>
        /// Tasks are operations on tools, for example, the drag resize task is an operation
        /// on the SelectionTool, and the click draw task is an operation on the CreationTool.
        /// 
        /// When a focused task is active we want to hide the ratings control because
        /// we don't know what the interaction will be.
        /// </summary>
        /// <param name="f"></param>
        private void OnFocusedTaskChanged(FocusedTask f) {
            bool nowFocused = f.Task != null;
            if (nowFocused != _isFocused) {
                _isFocused = nowFocused;

                Selection selection = Context.Items.GetValue<Selection>();
                if (selection.PrimarySelection != null) {
                    ModelItem[] removed;
                    ModelItem[] added;

                    if (nowFocused) {
                        removed = new ModelItem[] { selection.PrimarySelection };
                        added = new ModelItem[0];
                    }
                    else {
                        removed = new ModelItem[0];
                        added = new ModelItem[] { selection.PrimarySelection };
                    }

                    OnPolicyItemsChanged(new PolicyItemsChangedEventArgs(this, added, removed));
                }
            }
        }
    }
}
