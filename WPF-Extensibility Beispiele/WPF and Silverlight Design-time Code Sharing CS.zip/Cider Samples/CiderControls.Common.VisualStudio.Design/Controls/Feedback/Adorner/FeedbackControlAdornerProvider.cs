﻿using System;
using System.ComponentModel;
using System.Windows;
using CiderControls.Common.VisualStudio.Design.Infrastructure;
using CiderControls.Common.VisualStudio.Design.Resources;
using Microsoft.Windows.Design.Interaction;
using Microsoft.Windows.Design.Model;
using Microsoft.Windows.Design.Policies;
using System.Diagnostics;

namespace CiderControls.Common.VisualStudio.Design.Controls {

    //TODO 10 - FeedbackControlAdornerProvider

    /// <summary>
    /// This class implements an adorner provider for the Feedback control.
    /// The adorner contains a Rate control, which changes the Value of the Feedback 
    /// control.
    /// 
    /// The FeedbackControlSelectionPolicy provides for hiding of the adorner when 
    /// the Feedback control is being resized or moved.
    /// </summary>
    [UsesItemPolicy(typeof(FeedbackControlSelectionPolicy))]
    internal class FeedbackControlAdornerProvider : AdornerProvider {

        // Know that there are different ways to write this code.
        // The way illustrated is to create a member variable and then only create the adorner once.
        // Another way is to create the adorner each time it is Activated and then not maintain a member.
        private Rating _rating;
        private ModelItem _adornedModelItem;
        private AdornerPanel _adornerPanel;
        private bool _writingToModel;

        public FeedbackControlAdornerProvider() {
        }

        /// <summary>
        /// Determines which Tool's are supported by this adorner
        /// </summary>
        /// <param name="tool"></param>
        /// <returns>Returns true when the ToolBox SelectionTool is selected otherwise false.</returns>
        public override bool IsToolSupported(Tool tool) {
            // The main kinds of tools are:
            //   - CreationTool (when the toolbox is activated - and clicking means create new object)
            //   - SelectionTool (when clicking means select object)

            // For this adorner, we don't want it to be in the way of creating new objects so we'll hide on creation. 
            if (tool is SelectionTool) {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Activate is called when the policy (specified by the UsesItemPolicy attribute)
        /// for the adorner provider says it's found a new model item.  
        /// </summary>
        /// <param name="item"></param>
        protected override void Activate(ModelItem item) {

            //lazy create the _adornerPanel, only occurs once
            //
            // create a panel to hold the design time adorner controls for our ratings control.
            // the AdornerPanel can hold mulitple controls and can place things relative to 
            // the adorned object on the designer (via AdornerHorizontal/VerticalAlignment)

            if (_adornerPanel == null) {
                _adornerPanel = new AdornerPanel();
                _rating = new Rating();
                _adornerPanel.Children.Add(_rating);
                Adorners.Add(_adornerPanel);

                // NOTE:
                // if we wanted keyboard focus to go to this panel, use:
                // _adornerPanel.IsContentFocusable = true;

            }

            _adornedModelItem = item;
            // hook up to property change notifications on the adorned item on the design surface
            // when this occurs, we will update the rating control in the adorner.
            _adornedModelItem.PropertyChanged += new PropertyChangedEventHandler(_adornedModelItem_PropertyChanged);
            _rating.ValueSelected += new EventHandler<ValueSelectedEventArgs>(_rating_ValueSelected);

            AdornerPanel.SetAdornerHorizontalAlignment(_rating, AdornerHorizontalAlignment.Left);
            AdornerPanel.SetAdornerVerticalAlignment(_rating, AdornerVerticalAlignment.OutsideBottom);

            UpdateRatingValue(_adornedModelItem);

            base.Activate(item);
        }

        /// <summary>
        /// Given a model item and a rating control, use ComputedValue
        /// to calculate out what the current value should be for the rating.
        /// 
        /// While this looks like overkill to set a value, this is a good practice
        /// when setting value types from the Model.
        /// </summary>
        /// <param name="item"></param>
        private void UpdateRatingValue(ModelItem item) {
            if (_rating == null) {
                return;
            }
            // set up the initial property value
            ModelProperty ratingValueProperty = item.Properties[MyPlatformTypes.Rating.ValueProperty];

            Debug.Assert(ratingValueProperty != null, "item.Properties[MyPlatformTypes.Rating.ValueProperty] returned null");

            if (ratingValueProperty != null) {
                // computed value is the value currently being used in the runtime
                // after bindings/resources have been evaluated.  

                // ComputedValue can return null (in particular if something is broken with the document)
                // so you must always protect against null return values.
                object rawValue = ratingValueProperty.ComputedValue;
                if (rawValue != null) {
                    _rating.Value = (int)rawValue;
                }
                else {
                    _rating.Value = 0;
                }
            }
        }

        //TODO 10.1 - When the Rating control value is selected this method runs, updating the Value of the control.

        /// <summary>
        /// This is the callback when the adorner's value has changed.
        /// Apply the value change back to the document.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void _rating_ValueSelected(object sender, ValueSelectedEventArgs e) {
            try {
                _writingToModel = true;

                // The ModelEditingScope provides provides named transaction support when writing to the Model.
                // If an exception occurs within the using block or the editingScope is not Complete, the transaction
                // will be rolled back and no changes made to the model.
                // The string provided will show up in the undo dropdown in the VS Toolbar.
                using (ModelEditingScope editingScope = _adornedModelItem.BeginEdit(Strings.EditingContextDescription_Adornder_SetFeedbackValue)) {
                    ModelProperty modelProperty = _adornedModelItem.Properties.Find(MyPlatformTypes.Rating.ValueProperty);

                    Debug.Assert(modelProperty != null, "_adornedModelItem.Properties.Find(MyPlatformTypes.Rating.ValueProperty) returned null");

                    if (modelProperty != null) {
                        modelProperty.SetValue(e.Value);
                        editingScope.Complete();
                    }
                }

            }
            catch (Exception eX) {
                MessageBox.Show(eX.ToString(), Strings.ExceptionMessageCaption_Exception_Writing_to_Cider, MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally {
                _writingToModel = false;
            }
        }

        /// <summary>
        /// Deactivate is called when the policy says a previously active item is no longer within the policy. 
        /// </summary>
        protected override void Deactivate() {
            if (_adornedModelItem != null) {
                _adornedModelItem.PropertyChanged -= _adornedModelItem_PropertyChanged;
            }

            if (_rating != null) {
                _rating.ValueSelected -= _rating_ValueSelected;
            }

            base.Deactivate();
        }

        //TODO 10.2 - If the Feedback control's value is changed, update the Adorner control
        /// <summary>
        /// If the Feedback control's value is changed, update the Adorner control
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void _adornedModelItem_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e) {
            if (_writingToModel) {
                return;
            }

            if (e.PropertyName == Constants.STR_VALUE) {
                UpdateRatingValue(_adornedModelItem);
            }
        }
    }
}
