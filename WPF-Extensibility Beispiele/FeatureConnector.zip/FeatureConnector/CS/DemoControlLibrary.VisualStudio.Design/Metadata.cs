using System;
using DemoControlLibrary;

using Microsoft.Windows.Design.Metadata;
using Microsoft.Windows.Design.Features;

// The ProvideMetadata assembly-level attribute indicates to designers
// that this assembly contains a class that provides an attribute table. 
[assembly: ProvideMetadata(typeof(DemoControlLibrary.VisualStudio.Design.Metadata))]
namespace DemoControlLibrary.VisualStudio.Design
{
    // Container for any general design-time metadata to initialize.
    // Designers look for a type in the design-time assembly that 
    // implements IProvideAttributeTable. If found, designers instantiate 
    // this class and access its AttributeTable property automatically.
    internal class Metadata : IProvideAttributeTable 
    {
        public AttributeTable AttributeTable
        {
            get 
            {
                AttributeTableBuilder builder = new AttributeTableBuilder();
                InitializeAttributes(builder);
                return builder.CreateTable();
            }
        }
      
        private void InitializeAttributes(AttributeTableBuilder builder) 
        {
            builder.AddCallback(typeof(DemoButton), AddButtonAttributes);
        }

        private void AddButtonAttributes(AttributeCallbackBuilder builder)
        {
            builder.AddCustomAttributes(
                new FeatureAttribute(typeof(DiagnosticsMenuProvider))
            );
        }
    }
}
