Imports System
Imports System.Windows

' The DemoDockPanel control provides a DockPanel that
' has custom design-time behavior. 
Public Class DemoDockPanel
    Inherits System.Windows.Controls.DockPanel
End Class
