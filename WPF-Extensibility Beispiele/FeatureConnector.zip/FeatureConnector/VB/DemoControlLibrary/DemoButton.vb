Imports System
Imports System.Windows

' The DemoButton control provides a button that
' has custom design-time behavior. 
Public Class DemoButton
    Inherits System.Windows.Controls.Button
End Class
