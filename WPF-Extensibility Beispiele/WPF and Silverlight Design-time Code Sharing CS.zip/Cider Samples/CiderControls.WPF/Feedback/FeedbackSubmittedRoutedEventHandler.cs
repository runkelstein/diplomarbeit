﻿
namespace CiderControls {

    public delegate void FeedbackSubmittedRoutedEventHandler(object sender, FeedbackSubmittedRoutedEventArgs e);

}
