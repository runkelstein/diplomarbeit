Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Media.Imaging
Imports System.Windows.Shapes

Imports Microsoft.Windows.Design.Features

' The FeatureManagerDiagnostics class implements a window
' that displays the running and pending feature connectors.
Partial Public Class FeatureManagerDiagnostics
    Inherits Window

    Private featManager As FeatureManager

    Public Sub New()
        InitializeComponent()

    End Sub

    Public Sub Initialize(ByVal manager As FeatureManager)
        featManager = manager
        Bind()
    End Sub

    Private Sub OnRefreshClick(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Bind()
    End Sub

    ' Binds the activatedFeatures and pendingFeatures controls
    ' the FeatureManager's RunningConnectors and PendingConnectors\
    ' properties.
    Private Sub Bind()
        activatedFeatures.Items.Clear()
        pendingFeatures.Items.Clear()

        Dim info As FeatureConnectorInformation
        For Each info In featManager.RunningConnectors
            activatedFeatures.Items.Add(info)
        Next info

        For Each info In featManager.PendingConnectors
            pendingFeatures.Items.Add(info)
        Next info

    End Sub

End Class
