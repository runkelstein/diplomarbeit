﻿using System;
using CiderControls.Common.VisualStudio.Design.Infrastructure;
using CiderControls.Common.VisualStudio.Design.Registration;
using CiderControls.Silverlight.VisualStudio.Design.Types;
using Microsoft.Windows.Design.Metadata;

namespace CiderControls.Silverlight.VisualStudio.Design {

    //TODO  4 - SL - SilverlightTypeResolver

    /// <summary>
    /// Silverlight type resolver
    /// </summary>
    internal class SilverlightTypeResolver : RegistrationTypeResolver {

        /// <summary>
        /// Takes a platform neutral TypeIdentifier and returns back a platform specific Type.
        ///  For each of the types you are providing a design experience for, you must add an entry to this method.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public override Type GetPlatformType(TypeIdentifier id) {
            switch (id.Name) {

                //TODO  4.1 - SL - The Magic Step 1 
                //  This assembly does not have project reference any Silverlight assemblies,
                //     however it's tasked with returing Silverlight types.

                //  This assembly has a FILE REFERENCE (as opposed to a project reference) 
                //  to the CiderControls.Silverlight.VisualStudio.Design.Types.dll

                //  SilverlightTypes class in the above assembly resolves the actual Silverlight types and are returned.

                case Constants.STR_CIDERCONTROLSFEEDBACK:
                    return SilverlightTypes.FeedbackControlType;

                case Constants.STR_CIDERCONTROLSRATING:
                    return SilverlightTypes.RatingControlType;
            }

            throw new ArgumentOutOfRangeException("id.Name", id.Name, CiderControls.Common.VisualStudio.Design.Resources.Strings.ExceptionMessageValue_not_programmed);
        }
    }
}
