﻿using System;

//
// This should be in AssemblyInfo.cs - declaring here to make it obvious
//
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("CiderControls.Silverlight.VisualStudio.Design")]
[assembly: System.Runtime.CompilerServices.InternalsVisibleTo("CiderControls.Common.VisualStudio.Design")]

namespace CiderControls.Silverlight.VisualStudio.Design.Types {

//TODO  4.2 - SL - The Magic Step 2
// This class allows us to reference Silverlight types from the main (WPF) design time assembly without
// adding references to Silverlight to the main design time assembly which would cause issues with the XAML
// Markup compiler

// These are only used to register metadata and the rest of the design time is written using the extensibility model
// which is platform agnostic

    internal class SilverlightTypes {

        //TODO  4.3 - SL - The Magic Step 3
        //  For each of the types you are providing a design experience for, you must add an entry in the below code.
        //  This assembly references the Silverlight Feedback custom control assembly so it can return the specific type of the
        //      Silverlight Feedback control.

        public static readonly Type FeedbackControlType = typeof(CiderControls.Feedback);
        public static readonly Type RatingControlType = typeof(CiderControls.Rating);
    }
}
