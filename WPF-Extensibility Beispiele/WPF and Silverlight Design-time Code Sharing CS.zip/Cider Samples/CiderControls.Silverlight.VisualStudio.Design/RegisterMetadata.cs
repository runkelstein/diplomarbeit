﻿using CiderControls.Common.VisualStudio.Design.Registration;
using CiderControls.Silverlight.VisualStudio.Design;
using Microsoft.Windows.Design.Metadata;

//TODO  1 - SL - Visual Studio uses this attribute to locate and instantiate RegisterMetadata
//
// This should be in AssemblyInfo.cs - declaring here to make it obvious
//
[assembly: ProvideMetadata(typeof(RegisterMetadata))]

namespace CiderControls.Silverlight.VisualStudio.Design {

    //TODO  2 - SL - Register Metadata provides an AttributeTable (metadata)

    /// <summary>
    /// Metadata is used by VS to associate your control design code with the control
    /// Notice the SilverlightTypeResolver.  This is used by the CiderControlsAttributeTableBuilder to get
    /// platform specific types in platform neutral code.
    /// </summary>
    internal class RegisterMetadata : IProvideAttributeTable {

        AttributeTable IProvideAttributeTable.AttributeTable {
            get {
                //TODO  3 - SL - SilverlightTypeResolver provides SL Types to CiderControlsAttributeTableBuilder which is platform neutral
                CiderControlsAttributeTableBuilder builder = new CiderControlsAttributeTableBuilder(new SilverlightTypeResolver());
                return builder.CreateTable();
            }
        }
    }
}
